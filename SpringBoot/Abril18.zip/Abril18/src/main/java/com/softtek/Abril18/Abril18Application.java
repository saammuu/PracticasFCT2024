package com.softtek.Abril18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Abril18Application {

	public static void main(String[] args) {
		SpringApplication.run(Abril18Application.class, args);
	}

}
