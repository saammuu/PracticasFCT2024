package com.softtek.Abril18;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Abril18ApplicationTests {

	@Test
	void contextLoads() {
	}

}
