package com.softtek.fundamentos.modelo;

public interface IVehiculo {
	
	String moverse();

}
