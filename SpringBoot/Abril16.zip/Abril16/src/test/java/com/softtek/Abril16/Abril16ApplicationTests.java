package com.softtek.Abril16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Abril16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
