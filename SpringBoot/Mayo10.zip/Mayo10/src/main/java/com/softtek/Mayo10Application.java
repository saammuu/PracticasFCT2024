package com.softtek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mayo10Application {

	public static void main(String[] args) {
		SpringApplication.run(Mayo10Application.class, args);
	}

}
